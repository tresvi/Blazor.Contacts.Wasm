﻿using Blazor.Contacts.Wasm.Shared;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blazor.Contacts.Wasm.Repositories
{
    public class ContactRepository: IContactRepository
    {
        private readonly IDbConnection _dbConnection;

        public ContactRepository(IDbConnection dbConnection)
        {
            _dbConnection = dbConnection;
        }

        public async Task DeleteContact(int id)
        {
            string sql = @"Delete From Contacts Where Id = @Id";
            await _dbConnection.ExecuteAsync(sql, new { Id = id });
        }

        public async Task<IEnumerable<Contact>> GetAll()
        {
            try
            {
                string sql = @"Select FirstName, LastName, Phone, Address 
                From Contacts";

                IEnumerable<Contact> contact  = await _dbConnection.QueryAsync<Contact>(sql);
                return contact;
            }
            catch (Exception)
            {

                throw;
            }
            
        }

        public async Task<Contact> GetDetails(int id)
        {
            string sql = @"Select FirstName, LastName, Phone, Address 
                From Contacts 
                Where Id = @Id";

            return await _dbConnection.QueryFirstOrDefaultAsync<Contact>(sql, new { Id = id });
        }

        public async Task<bool> InsertContact(Contact contact)
        {
            try
            {
                string sql = @" INSERT Into Contacts(FirstName, LastName, Phone, Address)
                    Values(@FirstName, @LastName, @Phone, @Address)";

                var result = await _dbConnection.ExecuteAsync(sql, new 
                    {
                        contact.FirstName, 
                        contact.LastName, 
                        contact.Phone, 
                        contact.Address 
                    });

                return result > 0;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public async Task<bool> UpdateContact(Contact contact)
        {
            try
            {
                string sql = @"Update Contacts 
                    Set FirstName = @FirstName,
                        LastName = @LastName,
                        Phone = @Phone,
                        Address = @Phone
                    Where Id = @Id";

                var result = await _dbConnection.ExecuteAsync(sql, new[]
                    {
                        contact.FirstName,
                        contact.LastName,
                        contact.Phone,
                        contact.Address,
                        contact.Id.ToString()
                    });

                return result > 0;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

}
